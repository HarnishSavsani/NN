# Rollback checklist
- [ ] Stop/limit traffic by approved procedure
- [ ] Disable new feature/agent/model/policy version
- [ ] Route to prior compatible images
- [ ] Preserve workflow/evidence/audit state
- [ ] Avoid blind reversal of external actions
- [ ] Reconcile ambiguous outcomes
- [ ] Validate service, data and security after rollback
- [ ] Record incident/change evidence
