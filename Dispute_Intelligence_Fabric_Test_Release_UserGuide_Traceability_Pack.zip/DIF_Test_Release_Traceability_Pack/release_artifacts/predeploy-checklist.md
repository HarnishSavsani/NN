# Pre-deployment checklist
- [ ] Artifacts signed and digests recorded
- [ ] Required tests passed/waived
- [ ] Migration and rollback tested
- [ ] Backups/restores verified
- [ ] Policy/AI versions approved
- [ ] Secrets and certificates ready
- [ ] Monitoring, alerts and on-call ready
- [ ] Feature flags/kill switches/fallback verified
