# Release Notes
## Scope
## Features and stories
## Database and event changes
## AI agent/model/prompt/tool changes
## Security and privacy impact
## Known issues and waivers
## Deployment and validation
## Rollback
## Support contacts
